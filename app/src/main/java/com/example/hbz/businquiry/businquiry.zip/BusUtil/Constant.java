package com.example.hbz.businquiry.BusUtil;

/**
 * @ClassName: com.example.besideyou
 * @Description:
 * @Author: HBZ
 * @Date: 2018/3/13 0:24
 */

public class Constant {
    public static final String APPKEY = "69783831ddf3043d";
    /**
     * 线路查询地址
     */
    public static final String LINE_URL = "http://api.jisuapi.com/transit/line";
    /**
     * 线路查询地址
     */
    public static final String STATION2S_URL = "http://api.jisuapi.com/transit/station2s";
    /**
     * 线路查询地址
     */
    public static final String STATIO_NURL = "http://api.jisuapi.com/transit/station";
    /**
     * 线路查询地址
     */
    public static final String NEARB_YURL = "http://api.jisuapi.com/transit/nearby";
    /**
     * 线路查询地址
     */
    public static final String CITY_URL = "http://api.jisuapi.com/transit/city";
}
